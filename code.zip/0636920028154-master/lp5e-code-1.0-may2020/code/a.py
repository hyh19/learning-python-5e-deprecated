import b     # File a.py
X = 111
