from mymod import countLines, countChars
print(countLines('mymod.py'), countChars('mymod.py'))
