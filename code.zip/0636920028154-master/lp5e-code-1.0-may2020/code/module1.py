def printer(x):                   # Module attribute
    print(x)
